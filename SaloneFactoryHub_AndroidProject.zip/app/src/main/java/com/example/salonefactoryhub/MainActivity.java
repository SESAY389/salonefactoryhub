
package com.example.salonefactoryhub;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Product> productList;
    ProductAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);

        productList = new ArrayList<>();
        productList.add(new Product("Jolaks Palm Oil (5L)", "https://via.placeholder.com/250x180.png?text=Palm+Oil", "Le 350", "Le 300"));
        productList.add(new Product("Star Lager Beer (24 pack)", "https://via.placeholder.com/250x180.png?text=Star+Lager", "Le 850", "Le 700"));
        productList.add(new Product("Maltina Non-Alcoholic (12 pack)", "https://via.placeholder.com/250x180.png?text=Maltina", "Le 420", "Le 360"));
        productList.add(new Product("Plastic Basin - Medium (Shankerdas)", "https://via.placeholder.com/250x180.png?text=Plastic+Basin", "Le 35", "Le 25"));
        productList.add(new Product("Bennimix Baby Cereal (1kg)", "https://via.placeholder.com/250x180.png?text=Baby+Cereal", "Le 95", "Le 80"));
        productList.add(new Product("Barrkee Mango Juice (1.5L)", "https://via.placeholder.com/250x180.png?text=Mango+Juice", "Le 55", "Le 45"));

        adapter = new ProductAdapter(this, productList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }
}

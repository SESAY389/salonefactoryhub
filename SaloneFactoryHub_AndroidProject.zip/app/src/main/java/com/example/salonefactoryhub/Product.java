
package com.example.salonefactoryhub;

public class Product {
    String name;
    String imageUrl;
    String retailPrice;
    String wholesalePrice;

    public Product(String name, String imageUrl, String retailPrice, String wholesalePrice) {
        this.name = name;
        this.imageUrl = imageUrl;
        this.retailPrice = retailPrice;
        this.wholesalePrice = wholesalePrice;
    }
}

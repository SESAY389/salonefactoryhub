
package com.example.salonefactoryhub;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {
    Context context;
    ArrayList<Product> products;

    public ProductAdapter(Context context, ArrayList<Product> products) {
        this.context = context;
        this.products = products;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.product_card, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product p = products.get(position);
        holder.name.setText(p.name);
        holder.retail.setText("Retail: " + p.retailPrice);
        holder.wholesale.setText("Wholesale: " + p.wholesalePrice);
        Glide.with(context).load(p.imageUrl).into(holder.image);

        holder.contactBtn.setOnClickListener(v -> {
            String message = "Hello, I'm interested in " + p.name;
            String url = "https://wa.me/232XXXXXXXXX?text=" + Uri.encode(message);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return products.size();
    }

    public static class ProductViewHolder extends RecyclerView.ViewHolder {
        TextView name, retail, wholesale;
        ImageView image;
        Button contactBtn;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.productName);
            retail = itemView.findViewById(R.id.retailPrice);
            wholesale = itemView.findViewById(R.id.wholesalePrice);
            image = itemView.findViewById(R.id.productImage);
            contactBtn = itemView.findViewById(R.id.contactButton);
        }
    }
}
